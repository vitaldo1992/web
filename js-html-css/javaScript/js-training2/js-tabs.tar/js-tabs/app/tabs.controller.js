var myApp = angular.module("myApp",[]);
myApp.controller('tabs', ['$scope', function($scope){

	// $scope.

}])